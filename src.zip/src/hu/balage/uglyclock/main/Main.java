package hu.balage.uglyclock.main;

import hu.balage.uglyclock.frame.ScreenSaver;

public class Main {

	public static void main(String[] args) {
		new Main().start();
	}

	private void start() {
		new ScreenSaver().run();
	}

}
