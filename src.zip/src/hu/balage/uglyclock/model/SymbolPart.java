package hu.balage.uglyclock.model;

public enum SymbolPart {
	EMPTY(" "),
	LEFT("\u258C"),
	RIGHT("\u2590"),
	UP("\u2580"),
	DOWN("\u2584"),
	FULL("\u2588"),
	MID("\u25A0");
	
	private final String symbolPart;
	private SymbolPart(String symbolPart) {
		this.symbolPart = symbolPart;
	}
	public String getSymbolPart() {
		return symbolPart;
	}
	
}
