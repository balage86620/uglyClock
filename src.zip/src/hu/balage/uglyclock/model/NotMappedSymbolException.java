package hu.balage.uglyclock.model;

public class NotMappedSymbolException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotMappedSymbolException(String msg) {
		super(msg);
	}
}
