package hu.balage.uglyclock.model;
import java.util.Arrays;
import java.util.List;

public enum Symbol {
	ONE('1',Arrays.asList(
			SymbolPart.DOWN,SymbolPart.MID,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.UP,SymbolPart.UP,SymbolPart.UP,SymbolPart.UP)),
	TWO('2',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.MID,SymbolPart.UP,SymbolPart.MID,
			SymbolPart.UP,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.UP,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.DOWN)),
	THREE('3',Arrays.asList(
			SymbolPart.UP,SymbolPart.UP,SymbolPart.MID,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.MID,SymbolPart.MID,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.MID,SymbolPart.EMPTY)),
	FOUR('4',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.DOWN,SymbolPart.EMPTY,
			SymbolPart.UP,SymbolPart.DOWN,SymbolPart.FULL,SymbolPart.DOWN,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY)),
	FIVE('5',Arrays.asList(
			SymbolPart.FULL,SymbolPart.UP,SymbolPart.UP,SymbolPart.UP,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.MID,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.MID,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.MID)),
	SIX('6',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.MID,SymbolPart.UP,SymbolPart.UP,SymbolPart.MID,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.MID,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.MID)),
	SEVEN('7',Arrays.asList(
			SymbolPart.UP,SymbolPart.UP,SymbolPart.UP,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.RIGHT,SymbolPart.LEFT,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.RIGHT,SymbolPart.LEFT,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY)),
	EIGHT('8',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.EMPTY,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.MID,SymbolPart.MID,SymbolPart.EMPTY,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.UP,SymbolPart.UP,SymbolPart.EMPTY)),
	NINE('9',Arrays.asList(
			SymbolPart.MID,SymbolPart.UP,SymbolPart.UP,SymbolPart.MID,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.MID,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.MID,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.DOWN,SymbolPart.EMPTY)),
	ZERO('0',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.EMPTY,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.FULL,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.FULL,
			SymbolPart.EMPTY,SymbolPart.UP,SymbolPart.UP,SymbolPart.EMPTY)),
	SPACE(' ',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY)),
	DOT('.',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.DOWN,SymbolPart.DOWN,SymbolPart.EMPTY)),
	DOUBLEDOT(':',Arrays.asList(
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.FULL,SymbolPart.FULL,SymbolPart.EMPTY,
			SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY,SymbolPart.EMPTY));
	private final List<SymbolPart> symbolParts;
	private final char numeral;

	private Symbol(char numeral, List<SymbolPart> symbolParts) {
		this.numeral = numeral;
		this.symbolParts = symbolParts;
	}

	public final List<SymbolPart> getSymbolParts() {
		return symbolParts;
	}
	
	public String formToScreen() {
		StringBuilder builder = new StringBuilder();
		builder.append("<html>");
		builder.append("<pre>");
		for(int i=0; i < symbolParts.size(); i++) {
			builder.append(symbolParts.get(i).getSymbolPart());
			if(i > 0 && i % 4 == 3) {
				builder.append("<br />");
			}
		}
		builder.append("</pre>");
		builder.append("</html>");
		return builder.toString();
	}
	
	public static Symbol getSymbol(char numeral) throws NotMappedSymbolException {
		for(Symbol s : Symbol.values()) {
			if(s.numeral == numeral) {
				return s;
			}
		}
		throw new NotMappedSymbolException("This character has not been mapped: " + numeral);
	}
	
}
