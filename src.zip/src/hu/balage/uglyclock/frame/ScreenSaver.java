package hu.balage.uglyclock.frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GraphicsEnvironment;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import hu.balage.uglyclock.logic.TimeManager;

public class ScreenSaver {
	public void run() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			final JFrame screenSaverFrame = new JFrame();
			screenSaverFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			screenSaverFrame.setUndecorated(true);
			screenSaverFrame.setResizable(false);
			screenSaverFrame.getContentPane().setBackground(Color.BLACK);
			TimeManager timeManager = new TimeManager(new JPanel());
			Timer refresher = new Timer(1000, timeManager);
			screenSaverFrame.add(timeManager.getTimePanel(), BorderLayout.CENTER);
			AnyEventListener listener = new AnyEventListener(screenSaverFrame,refresher);
			screenSaverFrame.addKeyListener(listener);
			screenSaverFrame.addMouseListener(listener);
			screenSaverFrame.addMouseMotionListener(listener);
			screenSaverFrame.validate();
			screenSaverFrame.setVisible(true);
			GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(screenSaverFrame);
			refresher.start();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
