package hu.balage.uglyclock.frame;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.Timer;

public class AnyEventListener implements MouseListener,
											KeyListener,
											MouseMotionListener {
	private JFrame screenSaverFrame;
	private Timer timer;
	
	public AnyEventListener(JFrame screenSaverFrame, Timer refresher) {
		this.screenSaverFrame = screenSaverFrame;
		timer = refresher;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		screenSaverFrame.dispatchEvent(
				new WindowEvent(screenSaverFrame,WindowEvent.WINDOW_CLOSING));
		timer.stop();
	}

	@Override
	public void mouseEntered(MouseEvent e) {		
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		
	}

}
