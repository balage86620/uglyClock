package hu.balage.uglyclock.logic;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;

import javax.swing.JPanel;

import hu.balage.uglyclock.model.NotMappedSymbolException;
import hu.balage.uglyclock.model.Symbol;

public class TimeManager implements ActionListener {
	private JPanel timePanel;
	
	public TimeManager(JPanel timePanel) {
		this.timePanel = timePanel;
	}

	public void setTimePanel() {
		timePanel.setLayout(new GridBagLayout());
		timePanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		timePanel.setBackground(Color.BLACK);
		timePanel.setVisible(true);
		LocalTime now = LocalTime.now();
		StringBuilder timeBuilder = new StringBuilder();
		int h = now.getHour();
		if(h<10) {
			timeBuilder.append("0" + h);
		} else {
			timeBuilder.append(h);
		}
		timeBuilder.append(":");
		int m = now.getMinute();
		if(m<10) {
			timeBuilder.append("0" + m);
		} else {
			timeBuilder.append(m);
		}
		timeBuilder.append(":");
		int s = now.getSecond();
		if(s<10) {
			timeBuilder.append("0" + s);
		} else {
			timeBuilder.append(s);
		}
		String time = timeBuilder.toString();
		timePanel.removeAll();
		for(char c : time.toCharArray()) {
			try {
				Symbol symbol = Symbol.getSymbol(c);
				timePanel.add(TimePanelItem.getItem(symbol));
			} catch (NotMappedSymbolException e) {
				e.printStackTrace();
			}
		}
		timePanel.validate();		
	}
	
	public JPanel getTimePanel() {
		return timePanel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		setTimePanel();
	}

}
