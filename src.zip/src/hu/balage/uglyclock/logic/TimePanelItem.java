package hu.balage.uglyclock.logic;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

import hu.balage.uglyclock.model.Symbol;

public class TimePanelItem {
	
	public static JLabel getItem(Symbol symbol) {
		JLabel item = new JLabel(symbol.formToScreen());
		item.setVisible(true);
		item.setFont(new Font("Monospaced", 0, 12));    
		item.setForeground(Color.WHITE); 
		item.validate();
		return item;                                    
	}
}
